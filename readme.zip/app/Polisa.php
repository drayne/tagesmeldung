<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Yajra\Oci8\Eloquent\OracleEloquent as Eloquent;

class Polisa extends Model
{
    protected $table = 'polisa';
    protected $primaryKey = 'pol_brpol';
}


//id tip receiver subject body queued sent

