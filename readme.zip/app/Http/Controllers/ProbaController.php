<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Polisa;

class ProbaController extends Controller
{
    public function index(Polisa $polisa)
    {
        print_r(Polisa::find($polisa));
    }

}
