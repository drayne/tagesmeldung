<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

$proxy_url    = getenv('PROXY_URL');
$proxy_schema = getenv('PROXY_SCHEMA');

Route::get('/', function () {
    echo phpinfo();
});

Route::get('/proba/{polisa}', 'ProbaController@index');

Route::get('/testemail', function(){
//    echo file_get_contents('http://www.google.com');
//
    Mail::raw('Sending emails with Mailgun and Laravel is easy!', function($message)
    {
        $message->to('bojicic@gmail.com');
    });

    /*stream_context_set_default(['http'=>['proxy'=>'http://proxy.bobar.biz:8080']]);

    $str = file_get_contents('http://drib.tech');

    if($str === false)
    {
        print_r(error_get_last());
        die(__FILE__ . __LINE__);
    }

    echo htmlspecialchars($str);*/


/*    $url = 'http://google.com';
    $proxy = 'proxy.bobar.biz:8080';
//$proxyauth = 'user:password';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
//curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 1);
    $curl_scraped_page = curl_exec($ch);
    curl_close($ch);

    var_dump($curl_scraped_page) ; */

/*    $proxy = getenv('http_proxy');
    if (!empty($proxy)) {
        $proxy = str_replace('http://', 'tcp://', $proxy);
        echo "Found a proxy " . $proxy . PHP_EOL;
        $context = array(
            'http' => array(
                'proxy' => $proxy,
                'request_fulluri' => true,
                'verify_peer'      => false,
                'verify_peer_name' => false,
            ),
            "ssl"=>array(
                "verify_peer"=>false,
                "verify_peer_name"=>false
            )
        );
        stream_context_set_default($context);
    } else {
        echo "Proxy not found" . PHP_EOL;
    }

    $str = file_get_contents('http://drib.tech');
    echo $str;*/
});
